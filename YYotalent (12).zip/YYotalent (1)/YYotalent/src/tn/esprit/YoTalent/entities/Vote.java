/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tn.esprit.YoTalent.entities;

import java.util.Objects;

/**
 *
 * @author USER
 */
public class Vote {
    private int idV,nbrV;
    private String dateV;
    private int idU;
    private int idEv;
    private int idEST;

    public Vote() {
    }

    public Vote(int idV, int nbrV, String dateV, int idU, int idEv, int idEST) {
        this.idV = idV;
        this.nbrV = nbrV;
        this.dateV = dateV;
        this.idU = idU;
        this.idEv = idEv;
        this.idEST = idEST;
    }

    public Vote(int nbrV, String dateV, int idU, int idEv, int idEST) {
        this.nbrV = nbrV;
        this.dateV = dateV;
        this.idU = idU;
        this.idEv = idEv;
        this.idEST = idEST;
    }
    

    public int getIdV() {
        return idV;
    }

    public void setIdV(int idV) {
        this.idV = idV;
    }

    public int getNbrV() {
        return nbrV;
    }

    public void setNbrV(int nbrV) {
        this.nbrV = nbrV;
    }

    public String getDateV() {
        return dateV;
    }

    public void setDateV(String dateV) {
        this.dateV = dateV;
    }

    public int getIdU() {
        return idU;
    }

    public void setIdU(int idU) {
        this.idU = idU;
    }

    public int getIdEv() {
        return idEv;
    }

    public void setIdEv(int idEv) {
        this.idEv = idEv;
    }

    public int getIdEST() {
        return idEST;
    }

    public void setIdEST(int idEST) {
        this.idEST = idEST;
    }

    @Override
    public String toString() {
        return "Vote{" + "idV=" + idV + ", nbrV=" + nbrV + ", dateV=" + dateV + ", idU=" + idU + ", idEv=" + idEv + ", idEST=" + idEST + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Vote other = (Vote) obj;
        if (this.idV != other.idV) {
            return false;
        }
        if (this.nbrV != other.nbrV) {
            return false;
        }
        if (!Objects.equals(this.dateV, other.dateV)) {
            return false;
        }
        if (!Objects.equals(this.idU, other.idU)) {
            return false;
        }
        if (!Objects.equals(this.idEv, other.idEv)) {
            return false;
        }
        if (!Objects.equals(this.idEST, other.idEST)) {
            return false;
        }
        return true;
    }

  
  
 
    
}
