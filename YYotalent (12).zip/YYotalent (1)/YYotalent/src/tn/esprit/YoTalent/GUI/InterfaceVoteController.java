/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tn.esprit.YoTalent.GUI;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import tn.esprit.YoTalent.entities.Vote;
import tn.esprit.YoTalent.services.ServiceVote;
import tn.esprit.YoTalent.utils.MaConnexion;

/**
 * FXML Controller class
 *
 * @author hamza
 */
public class InterfaceVoteController implements Initializable {
    @FXML
    private TextField IdV;
    @FXML
    private TextField NbrV;
    @FXML
    private TextField DateV;
    @FXML
    private TextField IdU;
    @FXML
    private TextField IdEv;
    @FXML
    private TextField IdEST;
    @FXML
    private Button ModifyV;
    @FXML
    private TableView<?> AfficherV;
    @FXML
    private Button DeleteV;
    @FXML
    private Button AddV;
    @FXML
    private Button PartMG;
    @FXML
    private TextField del;
    
      private final Connection cnx;

    public InterfaceVoteController(){
        cnx = MaConnexion.getInstance().getCnx();
        
    }

    
    
    @FXML
     private void GoToPartic(ActionEvent event) throws IOException {
        Node node = (Node) event.getSource();
                    Stage stage = (Stage) node.getScene().getWindow(); 
                    stage.close();
                    Scene scene = new Scene(FXMLLoader.load(getClass().getResource("InterfacePartic.fxml")));       
                    stage.setScene(scene);
                    stage.setTitle("ParticMang");
                    
                    stage.show();
    }
     
     
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void btnMdfV(ActionEvent event) throws SQLException {
        
        ServiceVote v = new ServiceVote();
        Vote vm = new Vote(); 
        
        String idd = NbrV.getText();
        int nn = Integer.valueOf(idd);
        String iddd = IdU.getText();
        int nnn = Integer.valueOf(iddd);
        String idddd = IdEv.getText();
        int nnnn = Integer.valueOf(idddd);
        String iddddd = IdEST.getText();
        int nnnnn = Integer.valueOf(iddddd);
        
        
        vm.setNbrV(nn);
        vm.setDateV(DateV.getText());
        vm.setIdU(nnn);
        vm.setIdEv(nnnn);
        vm.setIdEST(nnnnn);
        v.updateOne(vm);
        IdV.clear();
        NbrV.clear();
        IdU.clear();
        DateV.clear();
        IdEST.clear();
        IdEv.clear();
        
        
    }

    @FXML
    private void btnDltV(ActionEvent event) {
        
         String n = IdV.getText();
        int id = Integer.valueOf(n);
		System.out.println(n);
                
        
        delete(id);
        IdV.clear();
        NbrV.clear();
        IdU.clear();
        DateV.clear();
        IdEST.clear();
        IdEv.clear();
        
    }

    public void delete(int id){
        try {
		String req = "DELETE FROM vote WHERE idV = '"+ id +"' ";
		PreparedStatement ste = cnx.prepareStatement(req);
		ste.executeUpdate();
		System.out.println("Vote deleted");
		
	} catch (SQLException ex) {
		Logger.getLogger(InterfaceVoteController.class.getName()).log(Level.SEVERE, null, ex);
	}
    
    
    
    }
    
    @FXML
    private void btnAddV(ActionEvent event) throws SQLException {
        
        ServiceVote v = new ServiceVote();
        Vote vv = new Vote(); 
        String id = IdV.getText();
        int n = Integer.valueOf(id);
        String idd = NbrV.getText();
        int nn = Integer.valueOf(idd);
        String iddd = IdU.getText();
        int nnn = Integer.valueOf(iddd);
        String idddd = IdEv.getText();
        int nnnn = Integer.valueOf(idddd);
        String iddddd = IdEST.getText();
        int nnnnn = Integer.valueOf(iddddd);
        
        vv.setIdV(n);
        vv.setNbrV(nn);
        vv.setDateV(DateV.getText());
        vv.setIdU(nnn);
        vv.setIdEv(nnnn);
        vv.setIdEST(nnnnn);
        v.createOne(vv);
        IdV.clear();
        NbrV.clear();
        IdU.clear();
        DateV.clear();
        IdEST.clear();
        IdEv.clear();
        
        
        
    }
    
}
