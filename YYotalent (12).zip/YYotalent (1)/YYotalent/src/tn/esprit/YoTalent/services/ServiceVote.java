/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package tn.esprit.YoTalent.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import tn.esprit.YoTalent.entities.Vote;
import tn.esprit.YoTalent.utils.MaConnexion;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author USER
 */
public class ServiceVote implements IService<Vote> {

     private final Connection cnx;

    public ServiceVote(){
        cnx = MaConnexion.getInstance().getCnx();
        
    }

    @Override
    public void createOne(Vote vote) throws SQLException {
        String req =   "INSERT INTO `vote`(`idV`,`nbrV`,`dateV` ,`idU`,`idEV`,`idEST`)" + "VALUES ('"+vote.getIdV()+"','"+vote.getNbrV()+"','"+vote.getDateV()+"','"+vote.getIdU()+"','"+vote.getIdEv()+"','"+vote.getIdEST()+"')";
        Statement st = cnx.createStatement();
        st.executeUpdate(req);
        System.out.println("Vote ajouté !");
    }

    @Override
    public void updateOne(Vote vote) throws SQLException {
       String sql = "UPDATE vote SET nbrV = ?, dateV = ?, idU = ?, idEV = ? , idEST = ? WHERE idV = ?";
        PreparedStatement ste;
        try {
            ste = cnx.prepareStatement(sql);
            


            ste.setInt(1, vote.getNbrV());
            ste.setString(2, vote.getDateV());
            ste.setInt(3, vote.getIdU());
            ste.setInt(4, vote.getIdEv());
            ste.setInt(5, vote.getIdEST());
            ste.setInt(6, vote.getIdV());

            

  

            

            ste.executeUpdate();
            int rowsUpdated = ste.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("La modification du vote :" + vote.getIdV() + " a été éffectuée avec succès ");
            }
        } catch (SQLException ex) {
            Logger.getLogger(ServiceVote.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }

    @Override
    public void deletOne(Vote vt) throws SQLException {
    
	
	try {
		String req = "DELETE FROM vote WHERE vote.`idV` = ?";
		PreparedStatement ste = cnx.prepareStatement(req);
		ste.setInt(1, vt.getIdV());
		ste.executeUpdate();
		System.out.println("Vote deleted");
		
	} catch (SQLException ex) {
		Logger.getLogger(ServiceVote.class.getName()).log(Level.SEVERE, null, ex);
	}
	
}

    @Override
    public List<Vote> selectAll() throws SQLException {
    List<Vote> vte = new ArrayList<>();

        String req = "SELECT * FROM `Vote`";
        PreparedStatement ps = cnx.prepareStatement(req);

        ResultSet rs = ps.executeQuery();

        while (rs.next()){

            Vote v = new Vote();

            v.setIdV(rs.getInt(1));
            v.setNbrV(rs.getInt("nbrv"));
            v.setDateV(rs.getString("dateV"));
            v.setIdU(rs.getInt("IdU"));
            v.setIdEv(rs.getInt("IdEv"));
            v.setIdEST(rs.getInt("IdEST"));
            
            vte.add(v);

        }


        return vte;
    }
        }

  
   
    
    
    

