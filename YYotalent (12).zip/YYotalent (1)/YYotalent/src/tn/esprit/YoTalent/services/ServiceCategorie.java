/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tn.esprit.YoTalent.services;


import tn.esprit.YoTalent.entities.Categorie;
import tn.esprit.YoTalent.utils.MaConnexion;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.PreparedStatement;



/**
 *
 * @author USER
 */
public class ServiceCategorie implements IService<Categorie> {
    private Connection cnx;

    public ServiceCategorie(){
        cnx = MaConnexion.getInstance().getCnx();
    }

    @Override
    public void createOne(Categorie categorie) throws SQLException {
      String req =   "INSERT INTO `categorie`(`nomCat`)" + "VALUES ('"+categorie.getNomCat()+"')";
        Statement st = cnx.createStatement();
        st.executeUpdate(req);
        System.out.println("Categorie ajouté !");
    }

    @Override
    public void updateOne(Categorie categorie) throws SQLException {
//      String sql = "UPDATE categorie SET `nomCat`=? WHERE idCat=" + categorie.getIdCat();
//        PreparedStatement ste;
//        
//        try {
//            ste = cnx.prepareStatement(sql);
//
//            ste.setString(1, categorie.getNomCat());
//
//            //ste.setString(2, categorie.getPassword());
//            
//           // ste.setString(3, categorie.getAccount_Date());
//
//       
//            ste.executeUpdate();
//            int rowsUpdated = ste.executeUpdate();
//            if (rowsUpdated > 0) {
//                System.out.println("La modification de categorie : " + categorie.getNomCat() + " a été éffectuée avec succès ");
//            }
//        } catch (SQLException ex) {
//            Logger.getLogger(ServiceCategorie.class.getName()).log(Level.SEVERE, null, ex);
//        }
    }

    @Override
    public void deletOne(Categorie t) throws SQLException {
//"DELETE FROM table_name WHERE some_column = some_value"
    }


    @Override
    public List<Categorie> selectAll() throws SQLException {
              List<Categorie> temp = new ArrayList<>();

        String req = "SELECT * FROM `Categorie`";
        PreparedStatement ps = cnx.prepareStatement(req);

        ResultSet rs = ps.executeQuery();

        while (rs.next()){

            Categorie Cat = new Categorie();

            Cat.setIdCat(rs.getInt(1));
            Cat.setNomCat(rs.getString("nomCat"));
           

            temp.add(Cat);

        }


        return temp;
    }
    }
    
    
    

    

    

