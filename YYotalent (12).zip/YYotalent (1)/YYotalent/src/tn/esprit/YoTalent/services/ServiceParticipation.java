/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tn.esprit.YoTalent.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import tn.esprit.YoTalent.entities.Participation;
import tn.esprit.YoTalent.utils.MaConnexion;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author USER
 */
public class ServiceParticipation implements IService<Participation> {

     private final Connection cnx;

    public ServiceParticipation(){
        cnx = MaConnexion.getInstance().getCnx();
        
    }
    
   @Override
    public void createOne(Participation participation) throws SQLException {
        String req =   "INSERT INTO `participation` (`idP`,`nbRemb`,`idEv`,`idU`,`idT`)" + "VALUES ('"+participation.getIdP()+"','"+participation.getNbRemb()+"','"+participation.getIdEv()+"','"+participation.getIdU()+"','"+participation.getIdT()+"')";
        Statement st = cnx.createStatement();
        st.executeUpdate(req);
        System.out.println("Participation ajoutée !");
    }

    @Override
    public void updateOne(Participation Participation) throws SQLException {
       String sql = "UPDATE 'participation' SET nbRemb = ?, idEv = ?, idU = ?, idT = ?";
        PreparedStatement ste;
        try {
            ste = cnx.prepareStatement(sql);
            


            ste.setInt(1, Participation.getNbRemb());
            ste.setInt(2, Participation.getIdEv());
            ste.setInt(3, Participation.getIdU());
            ste.setInt(4, Participation.getIdT());
           

            

  

            

            ste.executeUpdate();
            int rowsUpdated = ste.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("La modification du Participation :" + Participation.getIdP() + " a été éffectuée avec succès ");
            }
        } catch (SQLException ex) {
            Logger.getLogger(ServiceVote.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }

    @Override
    public void deletOne(Participation pt) throws SQLException {
    
	
	try {
		String req = "DELETE FROM participation WHERE participation.`idP` = ?";
		PreparedStatement ste = cnx.prepareStatement(req);
		ste.setInt(1, pt.getIdP());
		ste.executeUpdate();
		System.out.println("Participation deleted");
		
	} catch (SQLException ex) {
		Logger.getLogger(ServiceVote.class.getName()).log(Level.SEVERE, null, ex);
	}
	
}

    @Override
    public List<Participation> selectAll() throws SQLException {
    List<Participation> pte = new ArrayList<>();

        String req = "SELECT * FROM `Participation`";
        PreparedStatement ps = cnx.prepareStatement(req);

        ResultSet rs = ps.executeQuery();

        while (rs.next()){

            Participation p = new Participation();

            p.setIdP(rs.getInt(1));
            p.setNbRemb(rs.getInt("nbRemb"));
            p.setIdU(rs.getInt("IdU"));
            p.setIdEv(rs.getInt("IdEv"));
            p.setIdT(rs.getInt("IdT"));
            
            pte.add(p);

        }


        return pte;
    }  
}
