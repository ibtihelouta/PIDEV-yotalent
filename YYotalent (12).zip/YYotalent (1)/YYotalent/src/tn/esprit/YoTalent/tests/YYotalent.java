/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tn.esprit.YoTalent.tests;

/**
 *
 * @author USER
 */


import java.io.IOException;
 import tn.esprit.YoTalent.entities.Categorie;
import tn.esprit.YoTalent.services.ServiceCategorie;
import tn.esprit.YoTalent.entities.Evenement;
import tn.esprit.YoTalent.services.ServiceEvent;
import tn.esprit.YoTalent.utils.MaConnexion;
import tn.esprit.YoTalent.services.ServiceTicket;
import tn.esprit.YoTalent.entities.Ticket;
 import tn.esprit.YoTalent.entities.Participation;
import tn.esprit.YoTalent.services.ServiceParticipation;




import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import tn.esprit.YoTalent.entities.Vote;
import tn.esprit.YoTalent.services.ServiceVote;


public class YYotalent {
    
   


    public static void main(String[] args) {
   //  MaConnexion cn1 = MaConnexion.getInstance();
//        MaConnexion cn2 = MaConnexion.getInstance();
//        MaConnexion cn3 = MaConnexion.getInstance();
//        MaConnexion cn4 = MaConnexion.getInstance();
//
//   //   System.out.println(cn1.hashCode());
//        System.out.println(cn2.hashCode());
//        System.out.println(cn3.hashCode());
//        System.out.println(cn4.hashCode());

       Vote v = new Vote(4,"2023-01-8",2,62,1);
       Participation p = new Participation(5,2,62,1);
        
     
       //Evenement pt = new Evenement(62,"sarra","tgg","gyhgy","ggg");
     // Ticket t = new Ticket(2,55,62);
         
    
         
      // ServiceCategorie sc = new ServiceCategorie();
        ServiceParticipation sp = new ServiceParticipation();
//       // ServiceEvent se = new ServiceEvent();
        ServiceVote sv = new ServiceVote();
//
         try {
           
 //             sv.createOne(v);
//            sv.deletOne(v);
 //           sv.updateOne(v);
//            sp.createOne(p);
 //           sp.deletOne(p);
//            sp.updateOne(p);
            System.out.println(sp.selectAll());
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }


  }

}
